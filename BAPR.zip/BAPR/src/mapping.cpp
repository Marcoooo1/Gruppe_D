/**
 * @file mapping.cpp
 * @brief Implementierung des Occupancy-Grid-Mappings.
 */
#include "mapping.h"
#include <cmath>
#include <fstream>
#include <iostream>

OccupancyGridMap::OccupancyGridMap(int width, int height, float resolution)
    : width_(width), height_(height), resolution_(resolution) {
    // Ursprung in die Mitte der Karte legen
    origin_x_ = width_ / 2;
    origin_y_ = height_ / 2;
    // Grid initial mit "unbekannt" (128) füllen
    grid_.resize(width_ * height_, 128);
}

double OccupancyGridMap::computeYaw(const OdomData& odom) const {
    // Yaw aus Quaternion berechnen (angenommen Normalisierung gegeben)
    double w = odom.ori_w;
    double x = odom.ori_x;
    double y = odom.ori_y;
    double z = odom.ori_z;
    // Formel zur Berechnung von Yaw (Rotation um Z)
    double yaw = std::atan2(2.0 * (w * z + x * y),
                             w * w + x * x - y * y - z * z);
    return yaw;
}

void OccupancyGridMap::updateMap(const LaserScanData& scan, const OdomData& pose) {
    // Roboterposition in Weltkoordinaten
    double robot_x = pose.x;
    double robot_y = pose.y;
    // Orientierung (Yaw) des Roboters
    double robot_yaw = computeYaw(pose);
    // Roboterposition in Grid-Indizes umrechnen
    int robot_ix = static_cast<int>(std::round(origin_x_ + robot_x / resolution_));
    int robot_iy = static_cast<int>(std::round(origin_y_ - robot_y / resolution_));
    if (robot_ix < 0 || robot_ix >= width_ || robot_iy < 0 || robot_iy >= height_) {
        // Falls Roboter außerhalb der Kartengrenzen liegt (Sollte bei ausreichend großer Karte nicht passieren)
        return;
    }
    // Roboterzelle als frei markieren (Roboter-Standort ist befahrbar)
    grid_[robot_iy * width_ + robot_ix] = 255;
    // Alle Laser-Messstrahlen verarbeiten
    size_t count = scan.ranges.size();
    double angle = scan.angle_min;
    for (size_t i = 0; i < count; ++i) {
        float r = scan.ranges[i];
        // Ungültige oder NaN-Werte überspringen
        if (r != r) {  // Prüft auf NaN
            angle += scan.angle_increment;
            continue;
        }
        // Winkel des aktuellen Strahls im Weltkoordinatensystem
        double beam_angle = robot_yaw + angle;
        // Ermitteln, ob ein Hindernis getroffen wurde
        bool hit = true;
        if (std::isinf(r) || r >= scan.range_max) {
            hit = false;
            // Maximale Reichweite annehmen
            r = scan.range_max;
        } else if (r < scan.range_min) {
            // Messwert unterhalb der minimalen Reichweite ignorieren
            angle += scan.angle_increment;
            continue;
        }
        // Endpunkt des Strahls in Weltkoordinaten berechnen
        double end_x = robot_x + r * std::cos(beam_angle);
        double end_y = robot_y + r * std::sin(beam_angle);
        // Endpunkt in Grid-Koordinaten umrechnen
        int end_ix = static_cast<int>(std::round(origin_x_ + end_x / resolution_));
        int end_iy = static_cast<int>(std::round(origin_y_ - end_y / resolution_));
        // Endpunkt auf Kartenbereich begrenzen (falls außerhalb, auf Rand setzen)
        if (end_ix < 0) end_ix = 0;
        if (end_ix >= width_) end_ix = width_ - 1;
        if (end_iy < 0) end_iy = 0;
        if (end_iy >= height_) end_iy = height_ - 1;
        // Bresenham-Linienalgorithmus vom Roboter zum Endpunkt
        int x0 = robot_ix;
        int y0 = robot_iy;
        int x1 = end_ix;
        int y1 = end_iy;
        int dx = std::abs(x1 - x0);
        int dy = std::abs(y1 - y0);
        int sx = (x0 < x1) ? 1 : -1;
        int sy = (y0 < y1) ? 1 : -1;
        int err = dx - dy;
        int x = x0;
        int y = y0;
        if (hit) {
            // Strahl bis kurz vor dem Hindernis als frei markieren
            while (true) {
                if (x == x1 && y == y1) {
                    // Hinderniszelle erreicht, nicht als frei markieren
                    break;
                }
                grid_[y * width_ + x] = 255;  // freie Zelle
                int err2 = 2 * err;
                if (err2 > -dy) {
                    err -= dy;
                    x += sx;
                }
                if (err2 < dx) {
                    err += dx;
                    y += sy;
                }
                // Wenn der nächste Schritt die Hinderniszelle wäre, abbrechen (sie bleibt unmarkiert hier)
                if (x == x1 && y == y1) {
                    break;
                }
            }
            // Hindernis-Zelle als belegt markieren
            grid_[y1 * width_ + x1] = 0;
        } else {
            // Kein Hindernis: gesamten Strahl bis zum Endpunkt als frei markieren
            while (true) {
                grid_[y * width_ + x] = 255;
                if (x == x1 && y == y1) {
                    // Ende der Reichweite oder Kartenrand erreicht
                    break;
                }
                int err2 = 2 * err;
                if (err2 > -dy) {
                    err -= dy;
                    x += sx;
                }
                if (err2 < dx) {
                    err += dx;
                    y += sy;
                }
            }
        }
        // Winkel für den nächsten Strahl erhöhen
        angle += scan.angle_increment;
    }
}

bool OccupancyGridMap::saveMap(const std::string& filename) const {
    std::ofstream out(filename);
    if (!out.is_open()) {
        std::cerr << "Fehler: Konnte Datei " << filename << " nicht zum Schreiben öffnen.\n";
        return false;
    }
    // PGM Header schreiben (Plain PGM Format P2)
    out << "P2\n" << width_ << " " << height_ << "\n255\n";
    // Grid-Daten ausgeben
    for (int y = 0; y < height_; ++y) {
        for (int x = 0; x < width_; ++x) {
            unsigned char val = grid_[y * width_ + x];
            out << static_cast<int>(val);
            if (x < width_ - 1) out << " ";
        }
        out << "\n";
    }
    out.close();
    return true;
}
