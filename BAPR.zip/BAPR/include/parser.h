/**
 * @file parser.h
 * @brief Parser-Funktionen für eingehende LaserScan- und Odometry-Daten.
 */
#ifndef PROJECT_PARSER_H_
#define PROJECT_PARSER_H_

#include <string>
#include "messages.h"

/**
 * @brief Parst eine LaserScan-Nachricht (JSON-String) in eine Datenstruktur.
 * @param msg_str Eingangsstring der Nachricht (JSON-Format).
 * @return Ausgeparste LaserScanData-Struktur.
 */
LaserScanData parseLaserScan(const std::string& msg_str);

/**
 * @brief Parst eine Odometry-Nachricht (JSON-String) in eine Datenstruktur.
 * @param msg_str Eingangsstring der Nachricht (JSON-Format).
 * @return Ausgeparste OdomData-Struktur.
 */
OdomData parseOdometry(const std::string& msg_str);

#endif  // PROJECT_PARSER_H_
