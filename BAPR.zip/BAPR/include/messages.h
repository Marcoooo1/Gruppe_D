/**
 * @file messages.h
 * @brief Definition der Datenstrukturen für LaserScan- und Odometry-Nachrichten.
 */
#ifndef PROJECT_MESSAGES_H_
#define PROJECT_MESSAGES_H_

#include <vector>

/** 
 * @brief Datenstruktur für LaserScan-Nachrichten (ähnlich sensor_msgs/LaserScan).
 */
struct LaserScanData {
    // Zeitstempel der Messung
    double stamp;
    // Scan-Parameter
    float angle_min;
    float angle_max;
    float angle_increment;
    float time_increment;
    float scan_time;
    float range_min;
    float range_max;
    // Messwerte als Arrays
    std::vector<float> ranges;
    std::vector<float> intensities;
};

/** 
 * @brief Datenstruktur für Odometry-Nachrichten (ähnlich nav_msgs/Odometry).
 */
struct OdomData {
    double stamp;
    // Position
    double x;
    double y;
    double z;
    // Orientierung (Quaternion)
    double ori_x;
    double ori_y;
    double ori_z;
    double ori_w;
    // Geschwindigkeit (linear und angular)
    float lin_vel_x;
    float lin_vel_y;
    float lin_vel_z;
    float ang_vel_x;
    float ang_vel_y;
    float ang_vel_z;
};

#endif  // PROJECT_MESSAGES_H_
