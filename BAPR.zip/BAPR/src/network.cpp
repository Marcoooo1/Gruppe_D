/**
 * @file network.cpp
 * @brief Implementierung der Netzwerkfunktionen.
 */
#include "network.h"
#include <arpa/inet.h>
#include <cstring>
#include <iostream>
#include <sys/socket.h>
#include <unistd.h>

int connectToServer(const std::string& ip_address, int port) {
    // Socket erstellen
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        std::perror("socket() failed");
        return -1;
    }
    // Serveradresse konfigurieren
    sockaddr_in server_addr;
    std::memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);
    // IP-String in binäre Adresse umwandeln
    if (inet_pton(AF_INET, ip_address.c_str(), &server_addr.sin_addr) <= 0) {
        std::cerr << "Ungültige IP-Adresse: " << ip_address << std::endl;
        close(sock);
        return -1;
    }
    // Verbindung herstellen
    if (connect(sock, reinterpret_cast<sockaddr*>(&server_addr), sizeof(server_addr)) < 0) {
        std::perror("connect() failed");
        close(sock);
        return -1;
    }
    std::cout << "Verbunden mit " << ip_address << ":" << port << std::endl;
    return sock;
}
