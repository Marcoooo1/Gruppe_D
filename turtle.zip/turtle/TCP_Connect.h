#ifndef TCP_CONNECT_H
#define TCP_CONNECT_H

#include <string>
#include <winsock2.h>
#include <ws2tcpip.h>

// Winsock-Hilfsfunktionen
bool initWinsock();
void cleanupWinsock();

// NEU: Konstante für unbegrenzte Nachrichten
constexpr int UNLIMITED_MESSAGES = -1;
// ---------------------------
// JSON-Stream-Reader-Basis
// ---------------------------
class JsonStreamReader {
protected:
    std::string ip;
    int port;
    std::string outputFile;
    int maxMessages; // Anzahl der JSON-Nachrichten, die gespeichert werden sollen

public:
    JsonStreamReader(const std::string& ip, int port,
                     const std::string& outFile,
                     int maxMessages = 1);

    virtual ~JsonStreamReader();

    // Objekt direkt in std::thread verwendbar
    void operator()();

protected:
    virtual void run();
    SOCKET createAndConnectSocket();
};

// Spezifische Klassen f�r Laser & Odom
class LaserReader : public JsonStreamReader {
public:
    explicit LaserReader(const std::string& ip);
};

class OdomReader : public JsonStreamReader {
public:
    // Hier ist der Konstruktor vollständig definiert (Inline-Definition)
    explicit OdomReader(const std::string& ip)
        : JsonStreamReader(ip, 9998, "odom_output.json", UNLIMITED_MESSAGES) {}
};

// ---------------------------
// NEU: CommandClient f�r Port 9999
// ---------------------------
class CommandClient {
private:
    std::string ip;
    int port;
    SOCKET sock;
    bool connected;

public:
    explicit CommandClient(const std::string& ip, int port = 9999);
    ~CommandClient();

    // Einmalige Verbindung herstellen
    bool connectToServer();

    // Command-String an Turtlebot schicken
    bool sendCommand(const std::string& cmd);

    // Verbindung explizit schlie�en (optional, wird im Destruktor auch gemacht)
    void close();
};

#endif // TCP_CONNECT_H
