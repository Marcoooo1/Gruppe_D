#include <atomic>
#include <chrono>
#include <csignal>
#include <fstream>
#include <iostream>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "mapping.h"
#include "messages.h"
#include "network.h"
#include "parser.h"
// Include socket functions definitions
#include <sys/socket.h>
#include <unistd.h>

// Globale Flags und geteilte Daten
static std::atomic<bool> g_running(true);
static std::atomic<int> g_laserScanCount(0);
// Gemeinsame neueste Odometrie (für Mapping)
static std::mutex g_odomMutex;
static OdomData g_latestOdom;

// Vektoren zur Speicherung aller empfangenen Daten (für spätere Verarbeitung)
static std::vector<LaserScanData> g_scanDataList;
static std::vector<OdomData> g_odomDataList;

// Ausgabestreams für JSON-Logs
static std::ofstream g_laserLog;
static std::ofstream g_odomLog;

/**
 * Thread-Funktion zum Empfang der LaserScan-Daten.
 * @param sock Socket-Dateideskriptor für LaserScan-Daten.
 */
void laserScanReceiverThread(int sock) {
    char buffer[4096];
    std::string incomplete;
    while (g_running.load()) {
        // Empfang von Daten (blockierend)
        ssize_t len = recv(sock, buffer, sizeof(buffer) - 1, 0);
        if (len <= 0) {
            // Verbindung geschlossen oder Fehler
            break;
        }
        buffer[len] = '\0';
        std::string data = buffer;
        // Reste vom letzten Lesevorgang voranstellen
        if (!incomplete.empty()) {
            data = incomplete + data;
            incomplete.clear();
        }
        // Alle vollständigen Zeilen (Nachrichten) verarbeiten
        size_t pos;
        while ((pos = data.find('\n')) != std::string::npos) {
            std::string line = data.substr(0, pos);
            data.erase(0, pos + 1);
            if (line.size() == 0) {
                continue;
            }
            // LaserScan-JSON parsen
            LaserScanData scan = parseLaserScan(line);
            // Als JSON in Datei protokollieren (eine Zeile pro Nachricht)
            if (g_laserLog.is_open()) {
                g_laserLog << line << std::endl;
            }
            // Im Speicher speichern
            g_scanDataList.push_back(scan);
            // Scan-Zähler erhöhen (nur zu Informationszwecken)
            ++g_laserScanCount;
        }
        // Unvollständige Daten für den nächsten Durchlauf zwischenspeichern
        if (!data.empty()) {
            incomplete = data;
        }
    }
    // Socket schließen, wenn der Thread endet
    close(sock);
}

/**
 * Thread-Funktion zum Empfang der Odometry-Daten.
 * @param sock Socket-Dateideskriptor für Odometry-Daten.
 */
void odomReceiverThread(int sock) {
    char buffer[2048];
    std::string incomplete;
    while (g_running.load()) {
        ssize_t len = recv(sock, buffer, sizeof(buffer) - 1, 0);
        if (len <= 0) {
            break;
        }
        buffer[len] = '\0';
        std::string data = buffer;
        if (!incomplete.empty()) {
            data = incomplete + data;
            incomplete.clear();
        }
        size_t pos;
        while ((pos = data.find('\n')) != std::string::npos) {
            std::string line = data.substr(0, pos);
            data.erase(0, pos + 1);
            if (line.size() == 0) {
                continue;
            }
            OdomData odom = parseOdometry(line);
            if (g_odomLog.is_open()) {
                g_odomLog << line << std::endl;
            }
            // Neueste Odometrie im Shared Memory aktualisieren
            {
                std::lock_guard<std::mutex> lock(g_odomMutex);
                g_latestOdom = odom;
            }
            // Ggf. gesamte Odometrie-Historie speichern (für Mapping)
            g_odomDataList.push_back(odom);
        }
        if (!data.empty()) {
            incomplete = data;
        }
    }
    close(sock);
}

/**
 * Signal-Handler für SIGINT (Strg+C), um das Programm sauber zu beenden.
 */
void signalHandler(int) {
    g_running = false;
}

int main() {
    // IP-Adresse des Roboters (hier beispielhaft, ggf. anpassen)
    std::string robotIp = "192.168.100.53";
    int laserPort = 9997;
    int odomPort = 9998;
    int cmdPort = 9999;
    // Log-Dateien öffnen
    g_laserLog.open("laserscan_data.json");
    g_odomLog.open("odom_data.json");
    // Verbindungen zu den drei Ports aufbauen
    int laserSock = connectToServer(robotIp, laserPort);
    if (laserSock < 0) {
        return 1;
    }
    int odomSock = connectToServer(robotIp, odomPort);
    if (odomSock < 0) {
        close(laserSock);
        return 1;
    }
    int cmdSock = connectToServer(robotIp, cmdPort);
    if (cmdSock < 0) {
        close(laserSock);
        close(odomSock);
        return 1;
    }
    // Signal-Handler einrichten (für Ctrl+C)
    std::signal(SIGINT, signalHandler);
    // Threads für Datenempfang starten
    std::thread laserThread(laserScanReceiverThread, laserSock);
    std::thread odomThread(odomReceiverThread, odomSock);
    // Im Haupt-Thread: Bewegungsbefehle senden (z.B. vorwärts fahren, dann drehen)
    std::string forwardCmd = "{\"linear\": 0.1, \"angular\": 0.0}\n";
    std::string rotateCmd = "{\"linear\": 0.0, \"angular\": 0.5}\n";
    std::string stopCmd   = "{\"linear\": 0.0, \"angular\": 0.0}\n";
    // Vorwärtsbefehl senden (für 3 Sekunden)
    send(cmdSock, forwardCmd.c_str(), forwardCmd.size(), 0);
    std::this_thread::sleep_for(std::chrono::seconds(3));
    // Drehbefehl senden
    send(cmdSock, rotateCmd.c_str(), rotateCmd.size(), 0);
    std::this_thread::sleep_for(std::chrono::seconds(3));
    // Stoppbefehl senden
    send(cmdSock, stopCmd.c_str(), stopCmd.size(), 0);
    // Threads zum Beenden veranlassen und Daten-Sockets schließen
    g_running = false;
    close(laserSock);
    close(odomSock);
    // Auf Thread-Beendigung warten
    laserThread.join();
    odomThread.join();
    // Befehlssocket und Log-Dateien schließen
    close(cmdSock);
    if (g_laserLog.is_open()) g_laserLog.close();
    if (g_odomLog.is_open()) g_odomLog.close();
    // Mapping mit den gesammelten Daten durchführen
    OccupancyGridMap map(400, 400, 0.05f);
    // Jede aufgezeichnete LaserScan-Nachricht mit passendem Odometrie-Pose verknüpfen
    size_t scanCount = g_scanDataList.size();
    size_t odomCount = g_odomDataList.size();
    size_t odomIndex = 0;
    for (size_t i = 0; i < scanCount; ++i) {
        LaserScanData& scan = g_scanDataList[i];
        OdomData pose;
        if (odomCount == 0) {
            pose = OdomData();  // Falls keine Odometrie verfügbar
        } else {
            // Geeignete Odometrie (nach Zeitstempel) suchen
            while (odomIndex + 1 < odomCount &&
                   g_odomDataList[odomIndex + 1].stamp <= scan.stamp) {
                odomIndex++;
            }
            pose = g_odomDataList[odomIndex];
        }
        map.updateMap(scan, pose);
    }
    // Karte als PGM-Bild speichern
    map.saveMap("map.pgm");
    std::cout << "Mapping abgeschlossen. Karte in 'map.pgm' gespeichert." << std::endl;
    return 0;
}
