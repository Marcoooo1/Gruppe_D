/**
 * @file parser.cpp
 * @brief Implementierung des JSON-Parsers für LaserScan und Odometry.
 */
#include "parser.h"
#include <iostream>
#include <stdexcept>
// JSON-Bibliothek (nlohmann JSON)
#include <json.hpp>
using json = nlohmann::json;

LaserScanData parseLaserScan(const std::string& msg_str) {
    LaserScanData scan;
    try {
        json j = json::parse(msg_str);
        // Zeitstempel auslesen (wenn vorhanden)
        if (j.contains("header") && j["header"].contains("stamp")) {
            if (j["header"]["stamp"].contains("secs") && j["header"]["stamp"].contains("nsecs")) {
                double secs = j["header"]["stamp"]["secs"].get<double>();
                double nsecs = j["header"]["stamp"]["nsecs"].get<double>();
                scan.stamp = secs + nsecs * 1e-9;
            } else if (j["header"]["stamp"].is_number()) {
                scan.stamp = j["header"]["stamp"].get<double>();
            }
        } else if (j.contains("stamp")) {
            scan.stamp = j["stamp"].get<double>();
        } else {
            scan.stamp = 0.0;
        }
        // Scan-Parameter
        scan.angle_min = j.at("angle_min").get<float>();
        scan.angle_max = j.at("angle_max").get<float>();
        scan.angle_increment = j.at("angle_increment").get<float>();
        if (j.contains("time_increment")) {
            scan.time_increment = j["time_increment"].get<float>();
        } else {
            scan.time_increment = 0.0f;
        }
        if (j.contains("scan_time")) {
            scan.scan_time = j["scan_time"].get<float>();
        } else {
            scan.scan_time = 0.0f;
        }
        scan.range_min = j.at("range_min").get<float>();
        scan.range_max = j.at("range_max").get<float>();
        // Arrays
        scan.ranges = j.at("ranges").get<std::vector<float>>();
        if (j.contains("intensities")) {
            scan.intensities = j["intensities"].get<std::vector<float>>();
        } else {
            // Falls keine Intensitäten gesendet, mit Nullen füllen
            scan.intensities.assign(scan.ranges.size(), 0.0f);
        }
    } catch (const std::exception& e) {
        std::cerr << "Fehler beim Parsen LaserScan JSON: " << e.what() << std::endl;
    }
    return scan;
}

OdomData parseOdometry(const std::string& msg_str) {
    OdomData odom;
    try {
        json j = json::parse(msg_str);
        // Zeitstempel
        if (j.contains("header") && j["header"].contains("stamp")) {
            if (j["header"]["stamp"].contains("secs") && j["header"]["stamp"].contains("nsecs")) {
                double secs = j["header"]["stamp"]["secs"].get<double>();
                double nsecs = j["header"]["stamp"]["nsecs"].get<double>();
                odom.stamp = secs + nsecs * 1e-9;
            } else if (j["header"]["stamp"].is_number()) {
                odom.stamp = j["header"]["stamp"].get<double>();
            }
        } else if (j.contains("stamp")) {
            odom.stamp = j["stamp"].get<double>();
        } else {
            odom.stamp = 0.0;
        }
        // Pose (Position und Orientierung)
        if (j.contains("pose") && j["pose"].contains("pose")) {
            const json& pos = j["pose"]["pose"]["position"];
            odom.x = pos.at("x").get<double>();
            odom.y = pos.at("y").get<double>();
            odom.z = pos.at("z").get<double>();
            const json& ori = j["pose"]["pose"]["orientation"];
            odom.ori_x = ori.at("x").get<double>();
            odom.ori_y = ori.at("y").get<double>();
            odom.ori_z = ori.at("z").get<double>();
            odom.ori_w = ori.at("w").get<double>();
        } else if (j.contains("position")) {
            // Falls flaches Format (ohne verschachtelte pose-Struktur)
            odom.x = j["position"]["x"].get<double>();
            odom.y = j["position"]["y"].get<double>();
            odom.z = j["position"]["z"].get<double>();
            odom.ori_x = j["orientation"]["x"].get<double>();
            odom.ori_y = j["orientation"]["y"].get<double>();
            odom.ori_z = j["orientation"]["z"].get<double>();
            odom.ori_w = j["orientation"]["w"].get<double>();
        } else {
            odom.x = odom.y = odom.z = 0.0;
            odom.ori_x = odom.ori_y = odom.ori_z = 0.0;
            odom.ori_w = 1.0;
        }
        // Twist (Geschwindigkeit)
        if (j.contains("twist") && j["twist"].contains("twist")) {
            const json& lin = j["twist"]["twist"]["linear"];
            odom.lin_vel_x = lin.at("x").get<float>();
            odom.lin_vel_y = lin.at("y").get<float>();
            odom.lin_vel_z = lin.at("z").get<float>();
            const json& ang = j["twist"]["twist"]["angular"];
            odom.ang_vel_x = ang.at("x").get<float>();
            odom.ang_vel_y = ang.at("y").get<float>();
            odom.ang_vel_z = ang.at("z").get<float>();
        } else if (j.contains("linear") && j.contains("angular")) {
            // Flaches Format für Geschwindigkeiten
            odom.lin_vel_x = j["linear"]["x"].get<float>();
            odom.lin_vel_y = j["linear"]["y"].get<float>();
            odom.lin_vel_z = j["linear"]["z"].get<float>();
            odom.ang_vel_x = j["angular"]["x"].get<float>();
            odom.ang_vel_y = j["angular"]["y"].get<float>();
            odom.ang_vel_z = j["angular"]["z"].get<float>();
        } else {
            odom.lin_vel_x = odom.lin_vel_y = odom.lin_vel_z = 0.0f;
            odom.ang_vel_x = odom.ang_vel_y = odom.ang_vel_z = 0.0f;
        }
    } catch (const std::exception& e) {
        std::cerr << "Fehler beim Parsen Odometry JSON: " << e.what() << std::endl;
    }
    return odom;
}
