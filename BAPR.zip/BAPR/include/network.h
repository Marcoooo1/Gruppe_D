/**
 * @file network.h
 * @brief Funktionen zum Aufbau der TCP-Verbindungen.
 */
#ifndef PROJECT_NETWORK_H_
#define PROJECT_NETWORK_H_

#include <string>

/**
 * @brief Stellt eine TCP-Verbindung zu einem Server her.
 * @param ip_address IP-Adresse des Servers (z.B. TurtleBot3)
 * @param port Portnummer für die Verbindung
 * @return Socket-Deskriptor bei Erfolg, -1 bei Fehler
 */
int connectToServer(const std::string& ip_address, int port);

#endif  // PROJECT_NETWORK_H_
