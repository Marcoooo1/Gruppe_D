/**
 * @file mapping.h
 * @brief Occupancy-Grid-Mapping für einfaches SLAM.
 */
#ifndef PROJECT_MAPPING_H_
#define PROJECT_MAPPING_H_

#include <string>
#include <vector>
#include "messages.h"

/**
 * @brief OccupancyGridMap-Klasse zur Erstellung einer 2D-Karte aus LaserScan- und Odometry-Daten.
 */
class OccupancyGridMap {
public:
    /**
     * @brief Konstruktor.
     * @param width Breite des Grid (Zellenanzahl in X-Richtung).
     * @param height Höhe des Grid (Zellenanzahl in Y-Richtung).
     * @param resolution Auflösung (Meter pro Zelle).
     */
    OccupancyGridMap(int width, int height, float resolution);

    /**
     * @brief Integriert einen neuen LaserScan in die Karte.
     * @param scan LaserScan-Daten.
     * @param pose OdomData mit der Pose (Position und Orientierung) des Roboters zum Scan-Zeitpunkt.
     */
    void updateMap(const LaserScanData& scan, const OdomData& pose);

    /**
     * @brief Speichert die Karte als Bilddatei (PGM-Format).
     * @param filename Dateiname (mit .pgm Extension).
     * @return true bei Erfolg, false falls Speichern fehlgeschlagen.
     */
    bool saveMap(const std::string& filename) const;

private:
    int width_;
    int height_;
    float resolution_;
    int origin_x_;  // Kartenursprung (Index) für Weltkoordinate (0,0)
    int origin_y_;
    // Grid-Daten: 0=besetzt, 255=frei, 128=unbekannt
    std::vector<unsigned char> grid_;

    /**
     * @brief Berechnet die Yaw (Heading) aus einer Quaternion-Orientierung.
     * @param odom OdomData mit Orientierungs-Quaternion.
     * @return Yaw-Winkel (Radianten).
     */
    double computeYaw(const OdomData& odom) const;
};

#endif  // PROJECT_MAPPING_H_
